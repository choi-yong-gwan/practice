const express = require('express')
const app = express()

//public을 서버에 등록
app.use(express.static(__dirname + '/public'))


//ejs
app.set('view engine', 'ejs') 


//요청.body 쓰려고
app.use(express.json())
app.use(express.urlencoded({extended:true})) 


//DB 시작


const { MongoClient } = require('mongodb')

let db
const url = 'mongodb+srv://32204630:ftS3DlPaCL4BWqUh@cluster0.eukfw.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
new MongoClient(url).connect().then((client)=>{
  console.log('DB연결성공')
  db = client.db('forum')


  //서버 8080포트에 띄워라
    app.listen(8080, () => {
        console.log('http://localhost:8080 에서 서버 실행중')
    })


}).catch((err)=>{
  console.log(err)
})

//DB 끝













//메인페이지 방문시 html파일 내보내
app.get('/', function(요청, 응답) {
    응답.sendFile(__dirname + '/index.html')
  })




//들어오면 글자 출력하기


  app.get('/news', (요청, 응답)=>{
    응답.send('오늘 비옴')
  }) 

  app.get('/shop', (요청, 응답)=>{
    응답.send('쇼핑페이지입니다~~')
  }) 

  app.get('/write', (요청, 응답)=>{
    응답.render('write.ejs')
  }) 




  app.post('/add', async (요청, 응답)=>{
    console.log(요청.body)



    try{
      if (요청.body.title==''){
      응답.send('제목 없음')
      } else {
        await db.collection('post').insertOne({title : 요청.body.title, content : 요청.body.content})
        응답.redirect('/load')
      }
    }  catch(e) {
       console.log(e)
       응답.status(500).send('서버에러')
    }
  })


//패러미터 문법
app.get('/detail/:aaaa', async(요청,응답)=>{
  await db.collection('post').findOne({a:1})
  await db.collection('post').find().toArray()
  응답.render('detail.ejs')
})

//DB에서 데이터 출력 

  app.get('/load', async (요청, 응답) => {
    let result = await db.collection('post').find().toArray()
    // 응답.send(result[0].title)
    응답.render('list.ejs',{ 글목록 : result})
  })